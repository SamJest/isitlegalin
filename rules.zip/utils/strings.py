import math
import re
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime


_LOCKED_PLURALS = {
    "brass knuckles",
    "night vision goggles",
    "lock picking tools",
}

_ACTION_PHRASE_OVERRIDES = {
    "carry pepper spray": "carry pepper spray",
    "drive on footpath": "drive on the footpath",
    "drive on pavement": "drive on the pavement",
    "drive on sidewalk": "drive on the sidewalk",
    "drive over speed limit": "drive over the speed limit",
    "drive under influence": "drive under the influence",
    "drive uninsured": "drive without insurance",
    "drive with expired licence": "drive with an expired licence",
    "drive without inspection": "drive without a valid inspection",
    "drive without licence": "drive without a licence",
    "drive without license": "drive without a license",
    "drive without mot": "drive without an MOT",
    "drive without pollution certificate": "drive without a pollution certificate",
    "not wear seatbelt": "drive without wearing a seatbelt",
    "use phone while driving": "use a phone while driving",
}

_GERUND_OVERRIDES = {
    "be": "being",
    "carry": "carrying",
    "drive": "driving",
    "have": "having",
    "make": "making",
    "not": "not being",
    "own": "owning",
    "possess": "possessing",
    "use": "using",
}


def _js_string(value):
    if value is None:
        return ""
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if math.isinf(value):
            return "Infinity" if value > 0 else "-Infinity"
    return str(value)


def escapeHtml(value):
    return (
        _js_string(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def slugify(value):
    return re.sub(r"^-+|-+$", "", re.sub(r"[^a-z0-9]+", "-", _js_string(value).lower()))


def compactText(value):
    return re.sub(r"\s+", " ", _js_string(value)).strip()


def toSentence(value):
    text = compactText(value)

    if not text:
        return ""

    if re.search(r"[.!?]$", text):
        return text

    return f"{text}."


def _sentence_stem(value):
    return compactText(value).rstrip(".")


def expandLegalPoint(value, role="general"):
    text = compactText(value)

    if not text:
        return ""

    stem = _sentence_stem(text)
    lower = stem.lower()

    if role == "penalty_fine":
        if lower in {"varies by state", "varies by province", "varies by region"}:
            return "Financial penalties can vary by jurisdiction, so the exact amount depends on the local rules."
        if lower in {"possible fine", "possible fines"}:
            return "Penalties can include fines."
        if "fine" in lower:
            return toSentence(f"Penalties can include {lower}")

    if role == "penalty_jail":
        if lower in {"rare", "unlikely"}:
            return "Imprisonment appears to be rare, but it may still be possible in more serious cases."
        if lower in {"possible in serious cases", "rare but possible in severe cases", "rare but possible in serious cases"}:
            return "Imprisonment appears to be uncommon, but it may still be possible in more serious cases."
        if lower in {"possible imprisonment", "possible jail"}:
            return "In more serious cases, imprisonment may be possible."
        if lower.startswith("possible imprisonment for "):
            return toSentence(f"In more serious cases, imprisonment may be possible for {lower.removeprefix('possible imprisonment for ')}")
        if lower.startswith("possible in "):
            return toSentence(f"Imprisonment may be possible {lower.removeprefix('possible ')}")
        if "imprisonment" in lower or "jail" in lower:
            return toSentence(f"In more serious cases, penalties may include {lower}")

    if lower.startswith("none for "):
        return toSentence(f"In most cases, there is no general exception for {lower.removeprefix('none for ')}")

    if lower in {"special exemptions are rare", "certain exemptions may apply", "certain exemptions"}:
        return "Specific exemptions appear to be limited, so the general rule will usually control."

    if lower.startswith("rules vary by ") or lower.startswith("rules differ by "):
        area = lower.split(" by ", 1)[1]
        return toSentence(f"Rules can vary by {area}, so checking the local position is important")

    if lower in {"state laws vary", "rules differ widely", "highly location-dependent"}:
        return "Rules can vary by state or locality, so checking the local position is important."

    if lower in {"varies by region", "varies by state", "varies by province"}:
        return toSentence(f"The position can vary by {lower.split(' by ', 1)[1]}, so local practice may matter")

    if lower == "enforcement varies by region":
        return "Enforcement can vary by region, so local practice may matter."

    if lower.startswith("public carry requires "):
        return toSentence(f"Public carry generally requires {lower.removeprefix('public carry requires ')}")

    if lower == "public carry is restricted":
        return "Public carry is generally restricted."

    if lower == "public carry is prohibited":
        return "Public carry is generally prohibited."

    if lower in {"illegal unless permitted", "illegal unless licensed", "illegal unless authorised", "illegal unless authorized"}:
        return "This is generally illegal unless a specific permit, licence, or legal exemption applies."

    if lower in {"strict prohibition", "strict prohibition applies", "strict nationwide prohibition", "strict national prohibition", "clear prohibition"}:
        return "This is generally treated as a strict prohibition, with limited room for exceptions."

    if lower in {"strict enforcement", "strict enforcement applies", "strict enforcement policy", "enforcement is consistent"}:
        return "In practice, enforcement is generally strict."

    if lower.startswith("strict enforcement across "):
        return toSentence(f"In practice, enforcement is generally strict across {lower.removeprefix('strict enforcement across ')}")

    if lower in {"strict control applies", "strict controls apply"}:
        return "Strict controls generally apply, so even limited exceptions should be checked carefully."

    if lower in {"carry restrictions apply", "carry restrictions are stricter than ownership", "carry is the main issue", "regulation focuses on carry"}:
        return "The main legal risk is usually carrying the item rather than simply owning it."

    if lower in {"public carry rules are important", "public carry rules are strict", "carry rules are key"}:
        return "Public carry rules are often the part that matters most in practice."

    if lower in {"context matters", "context is important", "context is key", "context and intent are key", "context determines legality"}:
        return "The answer depends heavily on the surrounding circumstances, not just the item itself."

    if lower in {"intent affects legality", "intent determines legality", "intent is a key factor", "intent is key in prosecution", "intent is often decisive", "intent is decisive", "intent-based enforcement"}:
        return "Intent can be decisive, so authorities may look closely at the purpose and surrounding circumstances."

    if lower in {"reason is key", "reason for carry is key", "reason for carry is important", "reason for carry is critical"}:
        return "The reason for carrying it can be central to the legal analysis."

    if lower in {"design matters", "design and intent matter", "design and use both matter", "design determines legality", "design influences legality", "design determines classification", "technical specifications matter"}:
        return "Design features can affect how the item is classified, which can change the legal position."

    if lower in {"legal possession does not permit misuse", "legal possession does not allow unlawful use"}:
        return "Even where possession is allowed, misuse can still be illegal."

    if lower in {"generally allowed", "generally low risk", "generally low-risk item"}:
        return "This looks generally permissible, although the conditions and context still matter."

    if lower in {"legal status is unclear and risky", "unclear classification increases risk"}:
        return "The legal position appears unclear, which increases the practical risk of getting it wrong."

    if lower in {"strict interpretation", "strict interpretation of intent", "strict interpretation of weapon intent"}:
        return "Authorities may apply a strict interpretation, especially where intent is disputed."

    if lower == "vehicle may be confiscated":
        return "Authorities may be able to confiscate the vehicle."

    if lower == "vehicle may be impounded":
        return "Authorities may be able to impound the vehicle."

    if lower == "vehicle may be seized":
        return "Authorities may be able to seize the vehicle."

    if lower == "vehicle may be stopped or impounded":
        return "Authorities may be able to stop or impound the vehicle."

    if lower == "vehicle may be clamped":
        return "Authorities may be able to clamp the vehicle."

    if lower in {"driving ban likely", "licence ban likely", "licence disqualification likely", "licence suspension likely", "licence suspension common", "licence suspension may occur", "license suspension is common", "may lead to license suspension"}:
        return "A licence suspension or driving ban may also be possible, depending on the circumstances."

    if lower.startswith("points ") or lower.startswith("black points") or lower.startswith("demerit points"):
        if lower in {"points may apply", "black points applied", "demerit points apply", "demerit points may apply", "demerit points commonly apply", "demerit points often apply", "demerit points usually apply"}:
            return "Penalties may also affect the licence or driving record through points or a similar system."
        return toSentence(f"Penalties may also affect the licence or driving record, for example through {lower}")

    if lower == "repeat offences are treated more seriously" or lower == "repeat offences increase penalties":
        return "Repeat offences are usually treated more seriously."

    if lower == "zero tolerance":
        return "A zero-tolerance approach generally applies."

    if role == "exception":
        if lower in {"certain exemptions", "certain exemptions for specific cases"}:
            return "Certain exemptions may apply in specific cases."
        if lower == "declared off-road vehicles":
            return "Declared off-road vehicles may be treated differently."
        if lower.startswith("temporary permit"):
            return "Temporary permits may apply in limited cases."
        if lower.startswith("short grace period"):
            return "Short grace periods may apply in limited situations."
        if lower.startswith("medical exemption"):
            return "Medical exemptions may apply in limited situations."
        if lower.startswith("hands-free"):
            return toSentence(f"{stem} in limited situations")
        if lower.startswith("emergency call"):
            return "Emergency calls may be treated as a limited exception."
        if lower.startswith("emergency vehicle"):
            return "Emergency vehicles may be treated differently while responding to incidents."
        if lower.startswith("transport for "):
            return toSentence(f"{stem} may be treated differently")
        if lower.endswith(" use") and "may" not in lower and "allowed" not in lower and "permitted" not in lower:
            return toSentence(f"{stem} may be treated differently")

    if role == "condition":
        if lower.startswith("proof must"):
            return "Proof generally needs to be available if authorities ask for it."
        if lower.startswith("registration must be"):
            return toSentence(f"{stem}, and authorities may check that it is up to date")
        if lower.startswith("vehicles must be registered"):
            return "Vehicles generally need to be properly registered before they are used on public roads."
        if lower.startswith("applies to all ") or lower.startswith("applies to most "):
            return toSentence(f"This generally {lower}")
        if lower.startswith("must use designated"):
            return toSentence(f"In most cases, you must {lower}")
        if lower.startswith("must be declared"):
            return toSentence(f"In most cases, it {lower}")
        if lower.startswith("driving is restricted"):
            return "Driving there is generally restricted."

    if role == "enforcement":
        if lower.startswith("police") or lower.startswith("authorities"):
            return toSentence(stem)
        if lower == "strict enforcement":
            return "Authorities generally enforce this rule strictly."

    return toSentence(stem)


def capitalizeFirst(value):
    text = compactText(value)

    if not text:
        return ""

    return f"{text[:1].upper()}{text[1:]}"


def isPluralPhrase(value):
    phrase = compactText(value).lower()

    if not phrase:
        return False

    if phrase in _LOCKED_PLURALS:
        return True

    lastWord = phrase.split(" ")[-1] if phrase else ""

    if not lastWord:
        return False

    return re.search(r"(goggles|tools|knuckles)$", lastWord) is not None


def beVerbForPhrase(value):
    return "are" if isPluralPhrase(value) else "is"


def beQuestionVerbForPhrase(value):
    return "Are" if isPluralPhrase(value) else "Is"


def titleCase(value):
    words = [word for word in compactText(value).split(" ") if word]
    output = []

    for word in words:
        if len(word) <= 2 and word.isupper():
            output.append(word)
        else:
            output.append(f"{word[:1].upper()}{word[1:].lower()}")

    return " ".join(output)


def formatLocation(value):
    text = compactText(value)
    needsArticle = {
        "United Kingdom",
        "United States",
        "Netherlands",
        "Philippines",
        "Czech Republic",
        "Dominican Republic",
        "United Arab Emirates",
    }

    if not text:
        return ""

    return f"the {text}" if text in needsArticle else text


def startsWithArticle(value):
    text = compactText(value).lower()
    return bool(re.match(r"^(a|an|the)\b", text))


def addIndefiniteArticle(value):
    text = compactText(value)

    if not text or startsWithArticle(text) or isPluralPhrase(text):
        return text

    lowered = text.lower()

    if re.match(r"^(mot|puc)\b", lowered):
        article = "an" if lowered.startswith("m") else "a"
    else:
        article = "an" if re.match(r"^[aeiou]", lowered) else "a"

    return f"{article} {text}"


def normalizeActionPhrase(value, fallback=""):
    text = compactText(value).lower()

    if not text:
        return compactText(fallback).lower()

    if text in _ACTION_PHRASE_OVERRIDES:
        return _ACTION_PHRASE_OVERRIDES[text]

    return text


def toGerundPhrase(value):
    phrase = compactText(value).lower()

    if not phrase:
        return ""

    parts = phrase.split(" ", 1)
    firstWord = parts[0]
    remainder = parts[1] if len(parts) > 1 else ""

    gerund = _GERUND_OVERRIDES.get(firstWord)

    if gerund is None:
        if firstWord.endswith("ie"):
            gerund = f"{firstWord[:-2]}ying"
        elif firstWord.endswith("e") and firstWord not in {"be", "see"}:
            gerund = f"{firstWord[:-1]}ing"
        else:
            gerund = f"{firstWord}ing"

    return compactText(" ".join([gerund, remainder]))


def dedupe(values):
    seen = set()
    output = []

    for value in values or []:
        normalized = compactText(value)

        if not normalized:
            continue

        key = normalized.lower()

        if key in seen:
            continue

        seen.add(key)
        output.append(normalized)

    return output


def limitText(value, maxLength=160):
    text = compactText(value)

    if len(text) <= maxLength:
        return text

    return f"{text[: maxLength - 3].strip()}..."


def stripHtml(value):
    text = _js_string(value)
    text = re.sub(r"<script[\s\S]*?</script>", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def normalizeDate(value):
    text = compactText(value)
    local_timezone = datetime.now().astimezone().tzinfo

    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return text

    if re.fullmatch(r"\d{4}", text):
        return f"{text}-01-01"

    if not text:
        return ""

    iso_candidate = text.replace("Z", "+00:00")

    try:
        parsed = datetime.fromisoformat(iso_candidate)
    except ValueError:
        try:
            parsed = parsedate_to_datetime(text)
        except (TypeError, ValueError, IndexError, OverflowError):
            parsed = None

    if parsed is None:
        for pattern in (
            "%B %d, %Y",
            "%b %d, %Y",
            "%B %d %Y",
            "%b %d %Y",
            "%Y/%m/%d",
            "%m/%d/%Y",
            "%m-%d-%Y",
        ):
            try:
                parsed = datetime.strptime(text, pattern)
                break
            except ValueError:
                continue

    if parsed is None:
        return ""

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=local_timezone)
    else:
        parsed = parsed.astimezone(timezone.utc)

    return parsed.astimezone(timezone.utc).date().isoformat()


def singularizePhrase(value):
    phrase = compactText(value).lower()

    if not phrase or phrase in _LOCKED_PLURALS:
        return phrase

    words = phrase.split(" ")
    lastWord = words[-1] if words else ""

    if not lastWord:
        return phrase

    singular = lastWord

    if singular.endswith("ies"):
        singular = f"{singular[:-3]}y"
    elif singular.endswith("s") and not singular.endswith("ss"):
        singular = singular[:-1]

    words[-1] = singular
    return " ".join(words)
