QUERY_TYPE_ORDER = ["legal", "can-i", "consequences", "requirements"]


def pageId(page):
    return f'{page["country"]["slug"]}:{page["query_type"]}:{page["topic"]["slug"]}'


def toLink(page, reason):
    return {
        "href": page["canonical_path"],
        "label": page["query"],
        "reason": reason,
        "verdict": page["verdict"],
        "queryType": page["query_type_label"],
    }


def queryTypeOrderIndex(value):
    try:
        return QUERY_TYPE_ORDER.index(value)
    except ValueError:
        return -1


def pushUnique(target, candidates, reason, currentPage):
    for candidate in candidates:
        if candidate["canonical_path"] == currentPage["canonical_path"]:
            continue

        if any(item["href"] == candidate["canonical_path"] for item in target):
            continue

        target.append(toLink(candidate, reason))

        if len(target) >= 10:
            return


def attachRelatedLinks(pages):
    bySource = {}
    byTopicAndQueryType = {}
    byCountryAndQueryType = {}

    for page in pages:
        sourceKey = page["source_id"]
        topicKey = f'{page["topic"]["slug"]}:{page["query_type"]}'
        countryQueryKey = f'{page["country"]["slug"]}:{page["query_type"]}'

        if sourceKey not in bySource:
            bySource[sourceKey] = []

        if topicKey not in byTopicAndQueryType:
            byTopicAndQueryType[topicKey] = []

        if countryQueryKey not in byCountryAndQueryType:
            byCountryAndQueryType[countryQueryKey] = []

        bySource[sourceKey].append(page)
        byTopicAndQueryType[topicKey].append(page)
        byCountryAndQueryType[countryQueryKey].append(page)

    output = []

    for page in pages:
        links = []
        topicKey = f'{page["topic"]["slug"]}:{page["query_type"]}'
        countryQueryKey = f'{page["country"]["slug"]}:{page["query_type"]}'
        sameRulePages = [
            candidate
            for candidate in bySource.get(page["source_id"], [])
            if candidate["canonical_path"] != page["canonical_path"]
        ]

        pushUnique(links, sameRulePages, "Same rule, different intent", page)
        pushUnique(
            links,
            byTopicAndQueryType.get(topicKey, []),
            "Same topic in another country",
            page,
        )

        for relatedTopicSlug in page["related_topic_slugs"]:
            sameCountryPool = [
                candidate
                for candidate in byCountryAndQueryType.get(countryQueryKey, [])
                if candidate["topic"]["slug"] == relatedTopicSlug
            ]

            pushUnique(links, sameCountryPool, "Related action in the same country", page)

            if len(links) >= 10:
                break

        if len(links) < 5:
            pushUnique(
                links,
                [
                    candidate
                    for candidate in byCountryAndQueryType.get(countryQueryKey, [])
                    if pageId(candidate) != pageId(page)
                ],
                "Another rule in the same country",
                page,
            )

        query_type_links = [
            {
                "href": candidate["canonical_path"],
                "label": candidate["query_type_label"],
                "query": candidate["query"],
                "active": candidate["canonical_path"] == page["canonical_path"],
            }
            for candidate in sorted(
                bySource.get(page["source_id"], []),
                key=lambda candidate: queryTypeOrderIndex(candidate["query_type"]),
            )
        ]

        output.append(
            {
                **page,
                "query_type_links": query_type_links,
                "related_links": links[:10],
            }
        )

    return output
