import json
from datetime import datetime
from pathlib import Path

try:
    from .config.site import SITE_CONFIG, TEMPLATES_DIR
    from .utils.strings import compactText, escapeHtml, formatLocation
    from .utils.template import renderTemplate
except ImportError:
    from pygen.config.site import SITE_CONFIG, TEMPLATES_DIR
    from pygen.utils.strings import compactText, escapeHtml, formatLocation
    from pygen.utils.template import renderTemplate


PAGE_TEMPLATE_FILE = str(Path(TEMPLATES_DIR) / "page.html")

pageTemplate = None


def _json_stringify(value, indent=None):
    if indent is None:
        return json.dumps(value, ensure_ascii=False, separators=(",", ":")).replace(
            "<", "\\u003c"
        )

    return json.dumps(value, ensure_ascii=False, indent=indent).replace("<", "\\u003c")


def renderDocument(
    title,
    metaDescription,
    canonicalUrl,
    bodyClass="",
    schema=None,
    content="",
    headExtras="",
):
    if schema is None:
        schema = []

    schemaScripts = "\n".join(
        [
            f'<script type="application/ld+json">{item}</script>'
            for item in schema
            if item
        ]
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escapeHtml(title)}</title>
  <meta name="description" content="{escapeHtml(metaDescription)}">
  <meta name="robots" content="index,follow">
  <meta name="theme-color" content="#070b16">
  <link rel="canonical" href="{escapeHtml(canonicalUrl)}">
  <meta property="og:title" content="{escapeHtml(title)}">
  <meta property="og:description" content="{escapeHtml(metaDescription)}">
  <meta property="og:type" content="website">
  <meta property="og:url" content="{escapeHtml(canonicalUrl)}">
  <meta property="og:site_name" content="{escapeHtml(SITE_CONFIG["siteName"])}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="{escapeHtml(title)}">
  <meta name="twitter:description" content="{escapeHtml(metaDescription)}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Fraunces:wght@600;700&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/styles.css">
  {headExtras}
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-SDKGW2Z55L"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){{dataLayer.push(arguments);}}
  gtag('js', new Date());
  gtag('config', 'G-SDKGW2Z55L');
</script>
  {schemaScripts}
</head>
<body class="{escapeHtml(bodyClass)}">
{content}
<script src="/assets/site.js"></script>
</body>
</html>"""


def loadPageTemplate():
    global pageTemplate

    if pageTemplate is None:
        with open(PAGE_TEMPLATE_FILE, "r", encoding="utf8") as file:
            pageTemplate = file.read()

    return pageTemplate


def asJsonLd(value):
    return _json_stringify(value, indent=2)


def asInlineJson(value):
    return _json_stringify(value)


def formatDateLabel(value):
    try:
        parsed = datetime.strptime(f"{value}T00:00:00Z", "%Y-%m-%dT%H:%M:%SZ")
        return f"{parsed.day} {parsed.strftime('%B')} {parsed.year}"
    except Exception:
        return value


def buildVerdictView(page):
    if page["verdict"] == "Yes":
        return {
            "cardLabel": "Legal",
            "kicker": "Permissive baseline",
            "shortLabel": "Legal",
            "explainer": "The rule looks permissive at a baseline level, but storage, transport, import, or misuse rules can still narrow what is safe.",
        }

    if page["verdict"] == "No":
        return {
            "cardLabel": "Illegal",
            "kicker": "Prohibited baseline",
            "shortLabel": "Illegal",
            "explainer": "The safest read is prohibition unless a narrow and documented exception clearly fits your exact situation.",
        }

    return {
        "cardLabel": "Depends on context",
        "kicker": "Context-sensitive answer",
        "shortLabel": "Depends",
        "explainer": "The answer turns on purpose, labelling, permits, public use, or how local authorities classify the conduct.",
    }


def buildClarityView(page):
    if page["verdict"] == "Depends":
        return {
            "label": "Mixed or context-dependent",
            "note": "This is not a clean yes-or-no rule. The conditions and exceptions are part of the answer, not just footnotes.",
        }

    if page["confidence"]["score"] >= 64:
        return {
            "label": "Relatively clear baseline",
            "note": "The structured signals point in one direction, but primary sources still matter before any high-stakes decision.",
        }

    return {
        "label": "Clear enough for triage",
        "note": "This page gives a usable starting point, but you should verify the cited source trail before relying on it.",
    }


def renderListItems(items, emptyText):
    safeItems = [item for item in (items or []) if item]

    if not safeItems:
        return f"<li>{escapeHtml(emptyText)}</li>"

    return "\n".join([f"<li>{escapeHtml(item)}</li>" for item in safeItems])


def renderChecklist(items):
    output = []

    for index, item in enumerate(items or []):
        if not item:
            continue

        output.append(
            f"""
        <label class="check-item">
          <input type="checkbox" data-check-item="{index}">
          <span>{escapeHtml(item)}</span>
        </label>
      """.rstrip()
        )

    return "\n".join(output)


def renderFaq(items):
    output = []

    for item in items or []:
        if not item or not item.get("question") or not item.get("answer"):
            continue

        output.append(
            f"""
        <details>
          <summary>{escapeHtml(item["question"])}</summary>
          <p>{escapeHtml(item["answer"])}</p>
        </details>
      """.rstrip()
        )

    return "\n".join(output)


def renderStatRows(rows):
    output = []

    for row in rows:
        if not row or not row.get("value"):
            continue

        output.append(
            f"""
        <article class="stat-row">
          <p>{escapeHtml(row["label"])}</p>
          <h3>{escapeHtml(row["value"])}</h3>
          <span>{escapeHtml(row["detail"])}</span>
        </article>
      """.rstrip()
        )

    return "\n".join(output)


def renderMiniLinks(items):
    output = []

    for item in items:
        if not item or not item.get("href") or not item.get("title"):
            continue

        output.append(
            f"""
        <a class="mini-card" href="{escapeHtml(item["href"])}">
          <strong>{escapeHtml(item["title"])}</strong>
          <span>{escapeHtml(item.get("subtitle") or "")}</span>
        </a>
      """.rstrip()
        )

    return "\n".join(output)


def renderSources(sources):
    output = []

    for index, source in enumerate(sources or []):
        if not source:
            continue

        output.append(
            f"""
        <li>
          <strong>Source {index + 1}</strong><br>
          {escapeHtml(source)}
        </li>
      """.rstrip()
        )

    return "\n".join(output)


def renderPenaltyCards(page):
    cards = [
        {"label": "Fine exposure", "value": page["expanded_penalties"]["fine"]},
        {"label": "Jail exposure", "value": page["expanded_penalties"]["jail"]},
        {"label": "Penalty notes", "value": page["expanded_penalties"]["notes"]},
    ]

    output = []

    for card in cards:
        output.append(
            f"""
        <article class="penalty-card">
          <p class="penalty-card__label">{escapeHtml(card["label"])}</p>
          <p class="penalty-card__value">{escapeHtml(card["value"])}</p>
        </article>
      """.rstrip()
        )

    return "\n".join(output)


def renderIntentSwitcher(page):
    output = []

    for link in page.get("query_type_links") or []:
        output.append(
            f"""
        <a class="intent-pill{' intent-pill--active' if link['active'] else ''}" href="{escapeHtml(link["href"])}" aria-current="{'page' if link['active'] else 'false'}">
          <span>{escapeHtml(link["label"])}</span>
          <small>{escapeHtml(link["query"])}</small>
        </a>
      """.rstrip()
        )

    return "\n".join(output)


def renderContextLinks(page):
    links = [
        {"href": f'/{page["country"]["slug"]}/', "label": page["country"]["name"]},
        {"href": f'/{page["query_type"]}/', "label": page["query_type_label"]},
        {"href": f'/topics/{page["topic"]["slug"]}/', "label": page["topic"]["label"]},
    ]

    comparison = ((page.get("context") or {}).get("topicComparison") or {}).get(
        "canonical_path"
    )

    if comparison:
        links.append(
            {
                "href": comparison,
                "label": f'{page["topic"]["label"]} worldwide',
            }
        )

    return " | ".join(
        [
            f'<a href="{escapeHtml(item["href"])}">{escapeHtml(item["label"])}</a>'
            for item in links
        ]
    )


def dedupeByHref(items):
    seen = set()
    output = []

    for item in items:
        if not item or not item.get("href") or item["href"] in seen:
            continue

        seen.add(item["href"])
        output.append(item)

    return output


def dedupeText(items):
    seen = set()
    output = []

    for item in items:
        value = compactText(item)

        if not value:
            continue

        key = value.lower()

        if key in seen:
            continue

        seen.add(key)
        output.append(value)

    return output


def buildChecklistItems(page):
    return dedupeText(
        [
            *(page.get("expanded_conditions") or []),
            *(page.get("compliance_checklist") or []),
            ((page.get("expanded_exceptions") or [None])[0]),
            page["penalty_answer"],
        ]
    )[:8]


def buildQuickAnswer(page):
    if page["verdict"] == "Yes":
        return "Legal in principle, but the listed conditions and limits still matter."

    if page["verdict"] == "No":
        return "Treat this as generally prohibited unless a clear exception applies."

    return "The answer turns on context, purpose, permits, or how the situation is classified."


def buildTrustBlock(page):
    sourceLabel = "source" if len(page["sources"]) == 1 else "sources"
    return f"""
      <section class="trust-panel" aria-label="How to use this page">
        <div class="trust-panel__header">
          <p class="panel-kicker">Trust</p>
          <h2>Use this page as guidance, not legal advice</h2>
        </div>
        <div class="trust-panel__grid">
          <div class="trust-chip">
            <strong>Publisher</strong>
            <span>Is It Legal In</span>
          </div>
          <div class="trust-chip">
            <strong>By</strong>
            <span>Sam Jones</span>
          </div>
          <div class="trust-chip">
            <strong>Last updated</strong>
            <span>{escapeHtml(formatDateLabel(page["last_updated"]))}</span>
          </div>
          <div class="trust-chip">
            <strong>Structured review</strong>
            <span>{len(page["sources"])} {sourceLabel} in view</span>
          </div>
        </div>
        <p class="trust-panel__body">This page is informational guidance built from the current structured source set. Verify the source trail and local official guidance before relying on it for travel, purchase, public carry, self-defence, or enforcement-sensitive decisions.</p>
      </section>
    """.rstrip()


def buildRelatedCards(page, context):
    cards = []

    cards.append(
        {
            "href": f'/{page["country"]["slug"]}/',
            "title": f'{page["country"]["name"]} law guide',
            "meta": "Jurisdiction hub",
            "summary": f'See the broader rule picture in {page["country"]["name"]} before relying on one page alone.',
        }
    )
    cards.append(
        {
            "href": f'/topics/{page["topic"]["slug"]}/',
            "title": f'{page["topic"]["label"]} legality worldwide',
            "meta": "Cross-country comparison",
            "summary": f'Compare how {page["topic"]["gerund_phrase"]} is treated across other jurisdictions.',
        }
    )

    for link in page.get("related_links") or []:
        cards.append(
            {
                "href": link["href"],
                "title": link["label"],
                "meta": f'Related answer | {link["queryType"]} | {link["verdict"]}',
                "summary": link["reason"],
            }
        )

    for candidate in (context.get("otherCountriesForTopic") if context else []) or []:
        cards.append(
            {
                "href": candidate["canonical_path"],
                "title": candidate["query"],
                "meta": f'Compare countries | {candidate["country"]["name"]} | {candidate["verdict"]}',
                "summary": f'Check whether the baseline answer changes in another country.',
            }
        )

    for candidate in (context.get("countryHighlights") if context else []) or []:
        cards.append(
            {
                "href": candidate["canonical_path"],
                "title": candidate["query"],
                "meta": f'Same country | {candidate["query_type_label"]} | {candidate["verdict"]}',
                "summary": f'Open another useful rule page from {page["country"]["name"]} for context.',
            }
        )

    output = []

    for card in dedupeByHref(cards)[:10]:
        output.append(
            f"""
        <a class="related-card" href="{escapeHtml(card["href"])}">
          <div class="related-card__meta">{card["meta"]}</div>
          <h3>{escapeHtml(card["title"])}</h3>
          <p>{escapeHtml(card["summary"])}</p>
        </a>
      """.rstrip()
        )

    return "\n".join(output)


def buildSignalCards(page, context, clarity, dataShare):
    countryStats = ((context or {}).get("country") or {}).get("stats")
    topicStats = ((context or {}).get("topic") or {}).get("stats")

    cards = [
        {
            "label": "Clarity",
            "value": clarity["label"],
            "text": f'{len(page["sources"])} sources in view.',
        },
        {
            "label": "Confidence",
            "value": page["confidence"]["label"],
            "text": f'{page["confidence"]["score"]}/100 confidence score.',
        },
        {
            "label": "Risk profile",
            "value": page["risk"]["label"],
            "text": f'{page["risk"]["score"]}/100 risk score.',
        },
        {
            "label": "Data coverage",
            "value": f'{round(dataShare * 100)}% data-driven',
            "text": f'{len(page["conditions"])} conditions, {len(page["exceptions"])} exceptions.',
        },
    ]

    if countryStats:
        cards[1] = {
            "label": "This country",
            "value": f'{len(context["country"]["pages"])} tracked topics',
            "text": f'{countryStats["Yes"]} yes | {countryStats["Depends"]} depends | {countryStats["No"]} no.',
        }

    if topicStats:
        cards[2] = {
            "label": "This topic",
            "value": f'{len(context["topic"]["pages"])} countries',
            "text": f'{topicStats["Yes"]} yes | {topicStats["Depends"]} depends | {topicStats["No"]} no.',
        }

    output = []

    for card in cards:
        output.append(
            f"""
        <article class="micro-card">
          <p>{escapeHtml(card["label"])}</p>
          <h3>{escapeHtml(card["value"])}</h3>
          <span>{escapeHtml(card["text"])}</span>
        </article>
      """.rstrip()
        )

    return "\n".join(output)


def buildCountrySnapshot(page, context):
    country = (context or {}).get("country")

    if not country:
        return renderStatRows(
            [
                {
                    "label": "Coverage",
                    "value": "Country context unavailable",
                    "detail": "The page still includes the core rule, but no hub-level snapshot was attached.",
                }
            ]
        )

    statRows = [
        {
            "label": "Verdict mix",
            "value": f'{country["stats"]["Yes"]} yes / {country["stats"]["Depends"]} depends / {country["stats"]["No"]} no',
            "detail": f'{len(country["pages"])} primary legal pages tracked for this country.',
        },
        {
            "label": "Region",
            "value": page["country"]["region"],
            "detail": "Use nearby hubs for comparison.",
        },
    ]

    quickLinks = []

    for candidate in country.get("topPages") or []:
        if candidate["canonical_path"] == page["canonical_path"]:
            continue

        quickLinks.append(
            {
                "href": candidate["canonical_path"],
                "title": candidate["topic"]["label"],
                "subtitle": f'{candidate["verdict"]} answer in {country["name"]}',
            }
        )

        if len(quickLinks) >= 3:
            break

    for peer in (context.get("regionPeers") if context else []) or []:
        quickLinks.append(
            {
                "href": f'/{peer["slug"]}/',
                "title": peer["name"],
                "subtitle": f'Compare another {page["country"]["region"]} jurisdiction',
            }
        )

        if len(quickLinks) >= 5:
            break

    extra = ("\n" + renderMiniLinks(quickLinks)) if quickLinks else ""
    return f"{renderStatRows(statRows)}{extra}"


def buildTopicSnapshot(page, context):
    topic = (context or {}).get("topic")

    if not topic:
        return renderStatRows(
            [
                {
                    "label": "Coverage",
                    "value": "Topic context unavailable",
                    "detail": "The page still includes the rule-level detail, but no topic-level comparison snapshot was attached.",
                }
            ]
        )

    statRows = [
        {
            "label": "Countries tracked",
            "value": f'{len(topic["pages"])}',
            "detail": f'Primary legal pages for {page["topic"]["label"].lower()}.',
        },
        {
            "label": "Global verdict mix",
            "value": f'{topic["stats"]["Yes"]} yes / {topic["stats"]["Depends"]} depends / {topic["stats"]["No"]} no',
            "detail": f'Check whether {page["location"]} is an outlier.',
        },
    ]

    comparisonLinks = []

    for candidate in (context.get("sameTopicIntentPages") if context else []) or []:
        if candidate["canonical_path"] == page["canonical_path"]:
            continue

        comparisonLinks.append(
            {
                "href": candidate["canonical_path"],
                "title": candidate["country"]["name"],
                "subtitle": f'{candidate["query_type_label"]} view | {candidate["verdict"]}',
            }
        )

        if len(comparisonLinks) >= 5:
            break

    extra = ("\n" + renderMiniLinks(comparisonLinks)) if comparisonLinks else ""
    return f"{renderStatRows(statRows)}{extra}"


def buildBreadcrumbs(page):
    return [
        {"label": "Home", "href": "/"},
        {"label": "Countries", "href": "/countries/"},
        {"label": page["country"]["name"], "href": f'/{page["country"]["slug"]}/'},
        {"label": page["query_type_label"], "href": f'/{page["query_type"]}/'},
        {"label": page["topic"]["label"]},
    ]


def buildCountryLinks(page, context):
    country = (context or {}).get("country") or {}
    items = []

    for candidate in country.get("topPages") or []:
        if candidate["canonical_path"] == page["canonical_path"]:
            continue

        items.append(
            {
                "href": candidate["canonical_path"],
                "title": candidate["query"],
                "subtitle": candidate["summary"],
            }
        )

        if len(items) >= 4:
            break

    return renderMiniLinks(items)


def renderBreadcrumbsHtml(items):
    output = []

    for index, item in enumerate(items):
        crumb = (
            f'<a href="{escapeHtml(item["href"])}">{escapeHtml(item["label"])}</a>'
            if item.get("href")
            else f'<span>{escapeHtml(item["label"])}</span>'
        )

        if index == 0:
            output.append(crumb)
        else:
            output.append(f'<span aria-hidden="true">/</span>{crumb}')

    return "".join(output)


def buildSummaryPoints(page):
    return dedupeText(
        [
            page["summary"],
            *(page.get("expanded_conditions") or [])[:2],
            *(page.get("expanded_exceptions") or [])[:1],
            page["penalty_answer"],
            page["expanded_enforcement"],
        ]
    )[:6]


def buildPracticalTakeaways(page):
    return dedupeText(
        [
            *(page.get("expanded_conditions") or [])[:2],
            *(page.get("expanded_exceptions") or [])[:2],
            page["penalty_answer"],
            page["expanded_enforcement"],
        ]
    )[:6]


def buildSchemas(page, breadcrumbs):
    faqItems = []

    for item in page.get("faq") or []:
        if not item or not item.get("question") or not item.get("answer"):
            continue

        faqItems.append(
            {
                "@type": "Question",
                "name": item["question"],
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": item["answer"],
                },
            }
        )

    schemas = [
        asJsonLd(
            {
                "@context": "https://schema.org",
                "@type": "Article",
                "headline": page["query"],
                "description": page["summary"],
                "datePublished": page["last_updated"],
                "dateModified": page["last_updated"],
                "author": {
                    "@type": "Person",
                    "name": "Sam Jones",
                },
                "publisher": {
                    "@type": "Organization",
                    "name": SITE_CONFIG["siteName"],
                },
                "mainEntityOfPage": page["canonical_url"],
            }
        ),
        asJsonLd(
            {
                "@context": "https://schema.org",
                "@type": "WebPage",
                "name": page["query"],
                "description": page["summary"],
                "url": page["canonical_url"],
            }
        ),
        asJsonLd(
            {
                "@context": "https://schema.org",
                "@type": "BreadcrumbList",
                "itemListElement": [
                    {
                        "@type": "ListItem",
                        "position": index + 1,
                        "name": item["label"],
                        **(
                            {"item": f'{SITE_CONFIG["baseUrl"]}{item["href"]}'}
                            if item.get("href")
                            else {}
                        ),
                    }
                    for index, item in enumerate(breadcrumbs)
                ],
            }
        ),
    ]

    if faqItems:
        schemas.append(
            asJsonLd(
                {
                    "@context": "https://schema.org",
                    "@type": "FAQPage",
                    "mainEntity": faqItems,
                }
            )
        )

    return schemas


def renderPage(page, context=None, dataShare=0.4):
    if context is None:
        context = {}

    page = {**page, "context": context}

    template = loadPageTemplate()
    breadcrumbs = buildBreadcrumbs(page)
    verdictView = buildVerdictView(page)
    clarity = buildClarityView(page)
    friendlyDate = formatDateLabel(page["last_updated"])
    renderedPage = renderTemplate(
        template,
        {
            "breadcrumbs_html": renderBreadcrumbsHtml(breadcrumbs),
            "location": escapeHtml(page["country"]["name"]),
            "region": escapeHtml(page["country"]["region"]),
            "query_type_label": escapeHtml(page["query_type_label"]),
            "h1": escapeHtml(page["h1"]),
            "summary": escapeHtml(page["summary"]),
            "direct_answer": escapeHtml(page["direct_answer"]),
            "copy_text": escapeHtml(f'{page["query"]} {page["summary"]}'),
            "context_links_html": renderContextLinks(page),
            "quick_answer": escapeHtml(buildQuickAnswer(page)),
            "query_type_switcher_html": renderIntentSwitcher(page),
            "verdict_slug": escapeHtml(page["verdict_slug"]),
            "verdict": escapeHtml(verdictView["cardLabel"]),
            "risk_label": escapeHtml(page["risk"]["label"]),
            "risk_score": escapeHtml(str(page["risk"]["score"])),
            "signal_cards_html": buildSignalCards(page, context, clarity, dataShare),
            "summary_points_html": renderListItems(buildSummaryPoints(page), page["summary"]),
            "checklist_key": escapeHtml(page["canonical_path"]),
            "decision_checklist_html": renderChecklist(buildChecklistItems(page)),
            "exceptions_html": renderListItems(
                page["expanded_exceptions"],
                "No explicit exceptions were captured in the current structured dataset.",
            ),
            "penalties_html": renderPenaltyCards(page),
            "enforcement": escapeHtml(page["expanded_enforcement"]),
            "practical_takeaways_html": renderListItems(
                buildPracticalTakeaways(page),
                "Use the source trail before acting on this rule.",
            ),
            "faq_html": renderFaq(page["faq"]),
            "related_links_html": buildRelatedCards(page, context),
            "country_links_html": buildCountryLinks(page, context),
            "country_snapshot_html": buildCountrySnapshot(page, context),
            "topic_label": escapeHtml(page["topic"]["label"]),
            "topic_snapshot_html": buildTopicSnapshot(page, context),
            "sources_html": renderSources(page["sources"]),
            "canonical_path": escapeHtml(page["canonical_path"]),
            "last_updated": escapeHtml(friendlyDate),
            "source_count": escapeHtml(str(len(page["sources"]))),
            "page_payload_json": asInlineJson(
                {
                    "href": page["canonical_path"],
                    "query": page["query"],
                    "country": page["country"]["name"],
                    "topic": page["topic"]["label"],
                    "queryType": page["query_type_label"],
                    "verdict": verdictView["shortLabel"],
                    "directAnswer": page["direct_answer"],
                    "summary": page["summary"],
                    "riskLabel": page["risk"]["label"],
                    "enforcement": page["expanded_enforcement"],
                }
            ),
        },
    )
    renderedPage = renderedPage.replace(
        '<div class="content-layout">',
        f'{buildTrustBlock(page)}\n\n    <div class="content-layout">',
        1,
    )

    return renderDocument(
        title=page["title"],
        metaDescription=page["meta_description"],
        canonicalUrl=page["canonical_url"],
        bodyClass=f'rule-page verdict-{page["verdict_slug"]}',
        schema=buildSchemas(page, breadcrumbs),
        content=renderedPage,
    )
