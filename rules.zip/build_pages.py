import json
import re

try:
    from .config.query_types import queryTypes
    from .config.site import SITE_CONFIG
    from .utils.strings import (
        compactText,
        dedupe,
        expandLegalPoint,
        formatLocation,
        toSentence,
    )
except ImportError:
    from pygen.config.query_types import queryTypes
    from pygen.config.site import SITE_CONFIG
    from pygen.utils.strings import (
        compactText,
        dedupe,
        expandLegalPoint,
        formatLocation,
        toSentence,
    )


def buildPenaltyAnswer(penalties):
    parts = []

    if compactText(penalties["fine"]) and compactText(penalties["fine"]) != "Not specified":
        parts.append(expandLegalPoint(penalties["fine"], "penalty_fine"))

    if compactText(penalties["jail"]) and compactText(penalties["jail"]) != "Not specified":
        parts.append(expandLegalPoint(penalties["jail"], "penalty_jail"))

    if compactText(penalties["notes"]):
        parts.append(expandLegalPoint(penalties["notes"], "general"))

    return " ".join(dedupe(parts))


def joinSentences(items, limit=None):
    values = items if limit is None else items[:limit]
    return " ".join([toSentence(value) for value in dedupe(values) if compactText(value)])


def expandPoints(items, role, limit=None):
    values = items if limit is None else items[:limit]
    return [
        expandLegalPoint(value, role)
        for value in dedupe(values)
        if compactText(value)
    ]


def pickVariant(rule, options, salt=0):
    key = f'{rule["country"]["slug"]}:{rule["topic"]["slug"]}:{salt}'
    index = sum(ord(char) for char in key) % len(options)
    return options[index]


def buildIntroSentence(rule):
    subject = rule["topic"]["gerund_phrase"]
    location = formatLocation(rule["location"])

    if rule["verdict"] == "Yes":
        return pickVariant(
            rule,
            [
                f"In {location}, {subject} is usually allowed at a baseline level.",
                f"The baseline position in {location} is that {subject} is generally legal.",
                f"As a starting point, {subject} is generally permitted in {location}.",
            ],
            1,
        )

    if rule["verdict"] == "No":
        return pickVariant(
            rule,
            [
                f"In {location}, {subject} is generally prohibited.",
                f"The baseline position in {location} is prohibition rather than permission for {subject}.",
                f"As a starting point, {subject} is generally not allowed in {location}.",
            ],
            2,
        )

    return pickVariant(
        rule,
        [
            f"In {location}, whether {subject} is legal depends on the exact circumstances.",
            f"The answer in {location} is context-sensitive rather than a clean yes or no for {subject}.",
            f"For {location}, {subject} sits in a grey area where the details can change the outcome.",
        ],
        3,
    )


def buildRuleDetail(rule):
    conditions = expandPoints(rule["conditions"], "condition", 2)
    exceptions = expandPoints(rule["exceptions"], "exception", 1)
    conditionsText = " ".join(conditions)
    exceptionsText = " ".join(exceptions)

    lines = []

    if conditions:
        lines.append(
            pickVariant(
                rule,
                [
                    f"The rule usually turns on whether the listed conditions are met: {conditionsText}",
                    f"What matters most is compliance with the listed conditions: {conditionsText}",
                    f"The practical rule is shaped by the following conditions: {conditionsText}",
                ],
                4,
            )
        )

    if exceptions:
        lines.append(
            pickVariant(
                rule,
                [
                    f"A narrow exception can still matter: {exceptionsText}",
                    f"The answer can also shift if an exception applies: {exceptionsText}",
                    f"One important qualification is the exception layer: {exceptionsText}",
                ],
                5,
            )
        )

    return " ".join([toSentence(line) for line in lines[:2]])


def buildContextLine(rule, risk):
    enforcement = expandLegalPoint(rule["enforcement"], "enforcement")
    penalty = buildPenaltyAnswer(rule["penalties"])

    if risk["slug"] == "high" and compactText(penalty):
        return pickVariant(
            rule,
            [
                f"In practice, this carries a high-risk profile because getting it wrong can trigger {penalty}",
                f"The real-world downside is meaningful here, with potential exposure including {penalty}",
                f"This is not just a technical rule, because mistakes can lead to {penalty}",
            ],
            6,
        )

    if compactText(enforcement):
        return pickVariant(
            rule,
            [
                f"In practice, enforcement matters as much as the headline rule: {enforcement}",
                f"Real-world treatment often comes down to enforcement, not just wording on paper: {enforcement}",
                f"Context from enforcement helps explain the practical risk: {enforcement}",
            ],
            7,
        )

    return pickVariant(
        rule,
        [
            f"The practical risk profile here is {risk['label'].lower()}, so the surrounding details still matter.",
            f"That means the real-world picture is {risk['label'].lower()}, not just a simple headline verdict.",
            f"So even where the headline answer looks simple, the practical exposure remains {risk['label'].lower()}.",
        ],
        8,
    )


def buildBaseSummary(rule):
    return " ".join(
        [
            toSentence(buildIntroSentence(rule)),
            buildRuleDetail(rule),
        ]
    ).strip()


def buildVerdictExplainer(rule):
    if rule["verdict"] == "Yes":
        return "The baseline answer looks permissive, but misuse, transport, import, and public-use rules can still narrow what is allowed."

    if rule["verdict"] == "No":
        return "The safest reading is prohibition unless you can point to a narrow and documented exemption that fits your exact situation."

    return "The answer flips on context, permits, labels, or how authorities classify the conduct, so the headline verdict is only the start of the analysis."


def buildConfidence(rule):
    score = 34

    score += min(len(rule["sources"]), 4) * 7
    score += min(len(rule["conditions"]), 3) * 4
    score += min(len(rule["exceptions"]), 2) * 3

    if rule["penalties"]["jail"] != "Not specified":
        score += 8

    if rule["penalties"]["fine"] != "Not specified":
        score += 5

    if rule["verdict"] == "Depends":
        score -= 10

    score = max(20, min(score, 82))

    if score >= 64:
        return {
            "score": score,
            "label": "Moderate confidence",
            "slug": "moderate",
            "note": "This page has a useful source trail and multiple structured signals, but it should still be checked against primary law before high-stakes reliance.",
        }

    if score >= 48:
        return {
            "score": score,
            "label": "Working answer",
            "slug": "working",
            "note": "This page is strong enough for triage and comparison, but you should verify the listed sources before acting on it.",
        }

    return {
        "score": score,
        "label": "Use extra caution",
        "slug": "caution",
        "note": "This page is still useful for orientation, but the answer needs careful verification before any purchase, travel, or self-defence decision.",
    }


def buildRiskProfile(rule):
    score = 22

    if rule["verdict"] == "No":
        score += 48
    elif rule["verdict"] == "Depends":
        score += 26

    if rule["penalties"]["jail"] != "Not specified":
        score += 18

    if rule["penalties"]["fine"] != "Not specified":
        score += 10

    if re.search(r"confiscation|criminal|prohibited|firearm|charges", rule["penalties"]["notes"], re.IGNORECASE):
        score += 8

    score = max(8, min(score, 96))

    if score >= 78:
        return {
            "score": score,
            "label": "High risk",
            "tone": "Treat this as a rule where mistakes can carry real consequences.",
            "slug": "high",
        }

    if score >= 48:
        return {
            "score": score,
            "label": "Guarded",
            "tone": "The answer turns on conditions, documentation, or context.",
            "slug": "guarded",
        }

    return {
        "score": score,
        "label": "Low risk",
        "tone": "The rule looks more permissive, but the details still matter.",
        "slug": "low",
    }


def buildFreshnessNote(rule):
    return toSentence(
        f'Last refreshed on {rule["last_updated"]} from the current structured source set. Verify the source trail before relying on the answer for travel, purchase, self-defence, or enforcement-sensitive decisions'
    )


def buildMemoryHook(rule):
    if rule["verdict"] == "Yes":
        return 'If you remember one thing, "legal" does not mean unrestricted. Stay inside the listed conditions and treat misuse or transport edge cases seriously.'

    if rule["verdict"] == "No":
        return f'If you remember one thing, treat {rule["topic"]["gerund_phrase"]} as prohibited in {formatLocation(rule["location"])} unless a narrow and documented exception clearly applies.'

    return "If you remember one thing, the outcome can flip on one missing detail such as the permit status, labelling, purpose, or context of use."


def buildSummaryPoints(rule, baseSummary, verdictExplainer, confidence, risk, freshnessNote):
    return dedupe(
        [
            baseSummary,
            verdictExplainer,
            expandLegalPoint(rule["conditions"][0], "condition")
            if len(rule["conditions"]) > 0
            else None,
            expandLegalPoint(rule["exceptions"][0], "exception")
            if len(rule["exceptions"]) > 0
            else None,
            confidence["note"],
            risk["tone"],
            freshnessNote,
        ]
    )[:6]


def buildComplianceChecklist(rule):
    checks = [
        *expandPoints(rule["conditions"], "condition", 2),
        "Check whether the listed exceptions match your exact situation before acting.",
        "Read the penalty notes so you understand what a wrong assumption could trigger.",
        "Use the source trail to verify the answer before relying on it for travel, purchase, or public use.",
    ]

    if rule["verdict"] == "Depends":
        checks[1:1] = [
            "Confirm whether permits, labels, purpose, or public-carry rules change the answer for your scenario."
        ]

    if rule["verdict"] == "No":
        checks[1:1] = [
            "If you cannot document an exception, do not assume carrying, importing, buying, or using it is safe."
        ]

    if rule["verdict"] == "Yes":
        checks[1:1] = [
            "Make sure the way you carry, use, store, or transport it still fits the allowed conditions."
        ]

    return dedupe(checks)[:6]


def buildDecisionSteps(rule, confidence):
    steps = []

    if rule["verdict"] == "No":
        steps.append("Start from prohibition, not from edge-case exceptions.")
    elif rule["verdict"] == "Depends":
        steps.append("Define the exact scenario first, because a small detail can change the result.")
    else:
        steps.append("Start from the permissive baseline, then test the limits before acting.")

    if len(rule["conditions"]) > 0 and rule["conditions"][0]:
        steps.append(expandLegalPoint(rule["conditions"][0], "condition"))

    if len(rule["exceptions"]) > 0 and rule["exceptions"][0]:
        steps.append(expandLegalPoint(rule["exceptions"][0], "exception"))

    steps.append(buildPenaltyAnswer(rule["penalties"]))
    steps.append(confidence["note"])

    return dedupe(steps)[:5]


def buildPracticalTakeaways(rule, risk, freshnessNote):
    items = []

    if rule["verdict"] == "No":
        items.append(
            f'If you are deciding today, the safest default is not to {rule["topic"]["action_label"]} without specialist confirmation.'
        )

    if rule["verdict"] == "Depends":
        items.append(
            "Do not rely on the headline verdict alone. Work through the conditions, exceptions, and enforcement notes before making a decision."
        )

    if rule["verdict"] == "Yes":
        items.append(
            "Use the green light carefully. Confirm storage, transport, misuse, and public-use limits before treating the answer as friction-free."
        )

    items.append(risk["tone"])
    items.append(expandLegalPoint(rule["enforcement"], "enforcement"))
    items.append(buildPenaltyAnswer(rule["penalties"]))
    items.append(freshnessNote)

    return dedupe(items)[:5]


def buildDirectAnswer(rule):
    subject = rule["topic"]["gerund_phrase"]
    location = formatLocation(rule["location"])

    if rule["verdict"] == "Yes":
        return f"Yes. {subject.capitalize()} is generally legal in {location}, although specific conditions or restrictions may still apply."

    if rule["verdict"] == "No":
        return f"No. {subject.capitalize()} is generally illegal in {location}, unless a narrow exception or legal justification clearly applies."

    return f"Depends. In {location}, {subject} may be legal depending on the circumstances, purpose, or local restrictions."


def buildPageTitle(page):
    year = page["last_updated"][:4]
    location = formatLocation(page["location"])
    topicLabel = page["topic"]["label"]
    titleOptions = {
        "legal": [
            f'{page["query"]} | {SITE_CONFIG["siteName"]}',
            f'{topicLabel} legality in {location} explained ({year}) | {SITE_CONFIG["siteName"]}',
        ],
        "can-i": [
            f'{page["query"]} | {SITE_CONFIG["siteName"]}',
            f'Can I {page["topic"]["action_label"]} in {location}? {year} guide | {SITE_CONFIG["siteName"]}',
        ],
        "consequences": [
            f'{page["query"]} ({year} penalties) | {SITE_CONFIG["siteName"]}',
            f'{topicLabel} penalties in {location} explained ({year}) | {SITE_CONFIG["siteName"]}',
        ],
        "requirements": [
            f'{page["query"]} ({year} rules) | {SITE_CONFIG["siteName"]}',
            f'{topicLabel} rules and paperwork in {location} ({year}) | {SITE_CONFIG["siteName"]}',
        ],
    }

    return pickVariant(page, titleOptions.get(page["query_type"]) or [page["query"]], 11)


def buildFaq(page):
    location = formatLocation(page["location"])

    return [
        {
            "question": page["query"],
            "answer": page["summary"],
        },
        {
            "question": f'What should I remember about {page["topic"]["gerund_phrase"]} in {location}?',
            "answer": page["memory_hook"],
        },
        {
            "question": f'What conditions matter for {page["topic"]["gerund_phrase"]} in {location}?',
            "answer": " ".join(expandPoints(page["conditions"], "condition")),
        },
        {
            "question": f'Are there exceptions for {page["topic"]["gerund_phrase"]} in {location}?',
            "answer": " ".join(expandPoints(page["exceptions"], "exception")),
        },
        {
            "question": f'What are the penalties for {page["topic"]["gerund_phrase"]} in {location}?',
            "answer": buildPenaltyAnswer(page["penalties"]),
        },
        {
            "question": f'How strong is the answer for {location}?',
            "answer": page["confidence"]["note"],
        },
        {
            "question": f'When does the answer change for {page["topic"]["gerund_phrase"]} in {location}?',
            "answer": " ".join(
                [
                    *expandPoints(page["conditions"], "condition"),
                    *expandPoints(page["exceptions"], "exception"),
                ]
            ),
        },
        {
            "question": f'How is {page["topic"]["gerund_phrase"]} enforced in {location}?',
            "answer": expandLegalPoint(page["enforcement"], "enforcement"),
        },
        {
            "question": f'What should I verify next about {page["topic"]["gerund_phrase"]} in {location}?',
            "answer": toSentence(
                " ".join(
                    [
                        " ".join(expandPoints(page["conditions"], "condition")),
                        " ".join(expandPoints(page["exceptions"], "exception")),
                        buildPenaltyAnswer(page["penalties"]),
                        f'Sources referenced for this page include {", ".join(page["sources"])}',
                    ]
                )
            ),
        },
    ]


def expandRulesToPages(rules):
    output = []

    for rule in rules:
        baseSummary = buildBaseSummary(rule)
        verdictExplainer = buildVerdictExplainer(rule)
        confidence = buildConfidence(rule)
        risk = buildRiskProfile(rule)
        freshnessNote = buildFreshnessNote(rule)
        memoryHook = buildMemoryHook(rule)
        contextLine = buildContextLine(rule, risk)
        penaltyLead = buildPenaltyAnswer(rule["penalties"])

        for queryType in queryTypes:
            query = queryType["buildQuery"](rule)
            summary = queryType["buildSummary"](
                rule,
                {
                    "baseSummary": baseSummary,
                    "verdictExplainer": verdictExplainer,
                    "confidence": confidence,
                    "risk": risk,
                    "freshnessNote": freshnessNote,
                    "memoryHook": memoryHook,
                    "contextLine": contextLine,
                    "penaltyLead": penaltyLead,
                },
            )
            canonicalPath = f'/{rule["country"]["slug"]}/{queryType["slug"]}/{rule["topic"]["slug"]}/'

            page = {
                **rule,
                "source_id": rule["id"],
                "query": query,
                "query_type": queryType["slug"],
                "query_type_label": queryType["label"],
                "intent_label": queryType["intentLabel"],
                "h1": query,
                "summary": toSentence(summary),
                "verdict_explainer": verdictExplainer,
                "canonical_path": canonicalPath,
                "canonical_url": f'{SITE_CONFIG["baseUrl"]}{canonicalPath}',
                "verdict_slug": rule["verdict"].lower(),
                "confidence": confidence,
                "risk": risk,
                "freshness_note": freshnessNote,
                "memory_hook": memoryHook,
                "direct_answer": buildDirectAnswer(rule),
                "summary_points": buildSummaryPoints(
                    rule,
                    baseSummary,
                    verdictExplainer,
                    confidence,
                    risk,
                    freshnessNote,
                ),
                "compliance_checklist": buildComplianceChecklist(rule),
                "decision_steps": buildDecisionSteps(rule, confidence),
                "practical_takeaways": buildPracticalTakeaways(rule, risk, freshnessNote),
                "expanded_conditions": expandPoints(rule["conditions"], "condition"),
                "expanded_exceptions": expandPoints(rule["exceptions"], "exception"),
                "expanded_enforcement": expandLegalPoint(rule["enforcement"], "enforcement"),
                "penalty_answer": penaltyLead,
                "expanded_penalties": {
                    "fine": expandLegalPoint(rule["penalties"]["fine"], "penalty_fine"),
                    "jail": expandLegalPoint(rule["penalties"]["jail"], "penalty_jail"),
                    "notes": expandLegalPoint(rule["penalties"]["notes"], "general"),
                },
            }

            page["title"] = buildPageTitle(page)
            page["meta_description"] = compactText(queryType["buildMetaDescription"](page))
            page["faq"] = [
                json.loads(item)
                for item in dedupe(
                    [
                        json.dumps(item, ensure_ascii=False, separators=(",", ":"))
                        for item in buildFaq(page)
                    ]
                )
            ]

            output.append(page)

    return output
