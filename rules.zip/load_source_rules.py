import os
import re

try:
    from .config.site import RULES_DIR
    from .utils.fs import readJson, walkFiles
    from .utils.strings import (
        addIndefiniteArticle,
        compactText,
        dedupe,
        normalizeActionPhrase,
        normalizeDate,
        slugify,
        toGerundPhrase,
        toSentence,
    )
except ImportError:
    from pygen.config.site import RULES_DIR
    from pygen.utils.fs import readJson, walkFiles
    from pygen.utils.strings import (
        addIndefiniteArticle,
        compactText,
        dedupe,
        normalizeActionPhrase,
        normalizeDate,
        slugify,
        toGerundPhrase,
        toSentence,
    )


VALID_VERDICTS = {"Yes", "No", "Depends"}
PLACEHOLDER_PATTERN = re.compile(r"^(none|n/a|not specified)\.?$", re.IGNORECASE)


def cleanNarrativeText(value):
    text = compactText(value)

    if not text or PLACEHOLDER_PATTERN.search(text):
        return ""

    return re.sub(r"\s+(none|n/a|not specified)\.$", "", text, flags=re.IGNORECASE).strip()


def normalizeNarrativeList(values=None):
    if values is None:
        values = []

    output = []

    for value in values:
        cleaned = cleanNarrativeText(value)
        if cleaned:
            output.append(cleaned)

    return dedupe(output)


def normalizePenaltyBlock(penalties=None):
    if penalties is None:
        penalties = {}

    notes = cleanNarrativeText(penalties.get("notes"))

    return {
        "fine": cleanNarrativeText(penalties.get("fine")) or "Not specified",
        "jail": cleanNarrativeText(penalties.get("jail")) or "Not specified",
        "notes": toSentence(notes or "See source material for penalty detail"),
    }


def normalizeTopic(topic=None):
    if topic is None:
        topic = {}

    queryLabel = compactText(topic.get("query_label") or topic.get("label"))
    label = compactText(topic.get("label") or queryLabel)
    slug = compactText(topic.get("slug")) or slugify(queryLabel)
    actionPhrase = normalizeActionPhrase(topic.get("action_label"), label)
    nounPhrase = addIndefiniteArticle(label.lower())
    legalObject = compactText(topic.get("legal_object") or nounPhrase or label.lower())
    gerundPhrase = compactText(topic.get("gerund_phrase")) or toGerundPhrase(actionPhrase)
    naturalQuestion = compactText(topic.get("natural_question")) or f"Is it legal to {actionPhrase}?"

    return {
        "slug": slug,
        "label": label,
        "query_label": queryLabel.lower(),
        "action_label": actionPhrase or f"do {queryLabel.lower()}",
        "requirement_label": compactText(topic.get("requirement_label"))
        or f"permission for {queryLabel.lower()}",
        "legal_object": legalObject,
        "gerund_phrase": gerundPhrase or queryLabel.lower(),
        "natural_question": naturalQuestion,
        "category_slugs": dedupe(topic.get("category_slugs") or []),
    }


def normalizeCountry(country=None):
    if country is None:
        country = {}

    return {
        "slug": compactText(country.get("slug")),
        "name": compactText(country.get("name")),
        "region": compactText(country.get("region")),
    }


def normalizeRule(rule, sourceFile):
    country = normalizeCountry(rule.get("country"))
    topic = normalizeTopic(rule.get("topic"))
    verdict = compactText(rule.get("verdict"))
    lastUpdated = normalizeDate(rule.get("last_updated"))

    if not country["slug"] or not country["name"] or not country["region"]:
        raise Exception(f"Invalid country block in {sourceFile}")

    if not topic["slug"] or not topic["label"] or not topic["query_label"]:
        raise Exception(f"Invalid topic block in {sourceFile}")

    if verdict not in VALID_VERDICTS:
        raise Exception(f'Invalid verdict "{rule.get("verdict")}" in {sourceFile}')

    if not lastUpdated:
        raise Exception(f"Invalid last_updated value in {sourceFile}")

    return {
        "id": compactText(rule.get("id")) or f'{country["slug"]}-{topic["slug"]}',
        "query": compactText(rule.get("query")) or topic["query_label"],
        "location": compactText(rule.get("location")) or country["name"],
        "verdict": verdict,
        "summary": toSentence(cleanNarrativeText(rule.get("summary"))),
        "conditions": normalizeNarrativeList(rule.get("conditions")),
        "exceptions": normalizeNarrativeList(rule.get("exceptions")),
        "penalties": normalizePenaltyBlock(rule.get("penalties")),
        "enforcement": toSentence(cleanNarrativeText(rule.get("enforcement"))),
        "last_updated": lastUpdated,
        "sources": dedupe(rule.get("sources") or []),
        "country": country,
        "topic": topic,
        "related_topic_slugs": dedupe(rule.get("related_topic_slugs") or []),
    }


def loadSourceRules():
    files = [filePath for filePath in walkFiles(RULES_DIR) if filePath.endswith(".json")]

    if not files:
        raise Exception(
            f'No rule files found in {RULES_DIR}. Run "npm run import:legacy" inside V2 first.'
        )

    rules = []

    for filePath in files:
        payload = readJson(filePath)
        entries = payload if isinstance(payload, list) else [payload]

        for entry in entries:
            rules.append(normalizeRule(entry, os.path.relpath(filePath, RULES_DIR)))

    return sorted(
        rules,
        key=lambda rule: f'{rule["country"]["slug"]}/{rule["topic"]["slug"]}',
    )
